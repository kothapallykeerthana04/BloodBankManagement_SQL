
# Blood Bank Management System Using SQL

## Overview
A Blood Bank Management System to securely track donors, blood units, and recipient details. The system ensures compatibility checks, manages expiration of blood units, and maintains reliable donor information.

## Features
- Donor Management
- Blood Unit Inventory Tracking
- Recipient Management
- Compatibility and Expiration Checks
- Trigger-based Updates

## Technologies Used
- SQL (MySQL)
- MySQL Workbench / DBeaver

## Database Schema
- Donors
- BloodUnits
- Recipients
- Transfusions

## Author
Kothapally Keerthana
